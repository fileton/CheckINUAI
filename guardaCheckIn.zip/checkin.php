<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Checkin UAI</title>
</head>

<body>
<?php /* acá se recuperaría los datos del profesor que hará checkin
$nombreProfe=$_REQUEST[''];
$nombreClase=$_REQUEST[''];
*/

$con=mysql_connect("localhost","root","");
if (!$con)
  {
  die('no se pudo conectar: ' . mysql_error());
  }
$base=mysql_select_db("profesores",$con);
/*consulta que devuelve los ids pedidos(?)
$consultaid=mysql_query("SELECT id, id_clase FROM profesores a, clases b WHERE b.id = a.id_clase order by b.fecha limit 0, 1",$con);
*/
//consulta de prueba
$consulta=mysql_query("SELECT nombre, nombreClase FROM profesores a, clases b WHERE b.id = a.id_clase order by b.fecha limit 0, 1",$con);

$fila1= mysql_fetch_assoc($consulta);

$nombre=$fila1["nombre"];
$nombreClase=$fila1["nombreClase"];

//formato fecha
$fechaActual = date('Y/m/d H:i:s');
//Insertando los datos en la tabla
$query=mysql_query("Insert into checkin(nombre,nombreClase,fecha) values('$nombre','$nombreClase','$fechaActual')",$con);

if($query){
	echo $nombre." ha realizado CheckIn Uai en ".$nombreClase." con exito a las ".$fechaActual;
}
else {
 echo "ocurrio un error inesperado, intentelo nuevamente";	
}






?>

</body>
</html>